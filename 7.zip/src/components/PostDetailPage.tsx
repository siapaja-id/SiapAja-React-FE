import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, MessageCircle, Repeat2, Send, MoreHorizontal, BadgeCheck, Heart, Share, ChevronRight } from 'lucide-react';
import { FeedItem, SocialPostData, EditorialData, MediaCarousel } from './FeedItems';
import { IconButton, PostActions } from './PostActions';

// --- Stable Mock Thread Data ---
const MOCK_AUTHORS = [
  { name: 'Alice Smith', handle: 'alicesmith', avatar: 'https://picsum.photos/seed/alice/100/100', verified: false },
  { name: 'Bob Jones', handle: 'bobjones', avatar: 'https://picsum.photos/seed/bob/100/100', verified: true },
  { name: 'Charlie Day', handle: 'charlie_day', avatar: 'https://picsum.photos/seed/charlie/100/100', verified: false },
  { name: 'Diana Prince', handle: 'diana', avatar: 'https://picsum.photos/seed/diana/100/100', verified: true },
  { name: 'Evan Wright', handle: 'evanw', avatar: 'https://picsum.photos/seed/evan/100/100', verified: false },
];

const generateReplies = (parentPost: FeedItem, depth: number = 0): FeedItem[] => {
  if (depth > 3) return []; // Limit depth for mock
  
  const hash = parentPost.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const numReplies = (hash % 3) + 1; // 1 to 3 replies
  
  return Array.from({ length: numReplies }).map((_, i) => {
    const author = MOCK_AUTHORS[(hash + i) % MOCK_AUTHORS.length];
    return {
      id: `${parentPost.id}-r${i}`,
      type: 'social',
      author,
      content: depth === 0 
        ? `Interesting point! I think the ${i % 2 === 0 ? 'minimalist' : 'maximalist'} approach really shines here.`
        : `Replying to @${parentPost.author.handle}: That's a great observation about the flow.`,
      timestamp: `${(i + 1) * 2}h`,
      votes: (hash + i) % 100,
      replies: depth < 2 ? (hash % 3) + 1 : 0, // Only some have nested replies
      reposts: (hash + i) % 10,
      shares: (hash + i) % 5,
    } as FeedItem;
  });
};

// Simple cache for thread data
const threadCache: Record<string, FeedItem[]> = {};

const getReplies = (post: FeedItem): FeedItem[] => {
  if (!threadCache[post.id]) {
    threadCache[post.id] = generateReplies(post);
  }
  return threadCache[post.id];
};

// --- Components ---

const ThreadPost = ({
  post,
  isMain,
  isParent,
  hasLineBelow,
  onClick,
}: {
  post: FeedItem;
  isMain?: boolean;
  isParent?: boolean;
  hasLineBelow?: boolean;
  onClick?: () => void;
}) => {
  const isSocial = post.type === 'social';
  const isEditorial = post.type === 'editorial';
  const isTask = post.type === 'task';

  return (
    <article 
      className={`px-4 relative ${onClick ? 'cursor-pointer hover:bg-white/[0.02] transition-colors' : ''} ${isParent ? 'opacity-60 hover:opacity-100' : ''} ${isMain ? 'pt-2' : 'pt-4'}`}
      onClick={onClick}
    >
      <div className="flex gap-3">
        <div className="flex-shrink-0 flex flex-col items-center">
          <img 
            src={post.author.avatar} 
            alt={post.author.name} 
            className={`${isParent ? 'w-6 h-6' : 'w-10 h-10'} rounded-full object-cover ring-1 ring-white/10 z-10 bg-background transition-all`} 
            referrerPolicy="no-referrer" 
          />
          {hasLineBelow && (
            <div className={`w-0.5 grow mt-2 -mb-4 bg-white/5 rounded-full ${isParent ? 'min-h-[20px]' : 'min-h-[40px]'}`} />
          )}
        </div>
        <div className="flex-grow pb-4">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className={`${isParent ? 'text-[12px]' : 'text-[14px]'} font-bold text-on-surface`}>{post.author.name}</span>
              {post.author.verified && <BadgeCheck size={isParent ? 12 : 14} className="text-primary fill-primary" />}
              {!isParent && <span className="text-on-surface-variant text-[12px]">@{post.author.handle}</span>}
              <span className="text-on-surface-variant text-[12px]">· {post.timestamp}</span>
            </div>
            {!isParent && <IconButton icon={MoreHorizontal} />}
          </div>

          {isSocial && (
            <div className="mb-2">
              <p className={`leading-relaxed text-on-surface whitespace-pre-wrap ${isMain ? 'text-[16px]' : isParent ? 'text-[13px] line-clamp-1' : 'text-[14px]'}`}>
                {(post as SocialPostData).content}
              </p>
              {!isParent && (post as SocialPostData).images && (post as SocialPostData).images!.length > 0 && (
                <div className="-mx-4 sm:mx-0">
                  <MediaCarousel images={(post as SocialPostData).images!} aspect={isMain ? "aspect-[3/4]" : "aspect-[4/5]"} className="mt-3" />
                </div>
              )}
            </div>
          )}

          {isEditorial && !isParent && (
            <div className="mb-3">
              <div className="text-[9px] uppercase tracking-[0.2em] text-primary font-black mb-3">
                {(post as EditorialData).tag}
              </div>
              <h2 className="font-black text-xl text-on-surface leading-tight mb-3">
                {(post as EditorialData).title}
              </h2>
              <p className="text-[14px] leading-relaxed text-on-surface/80 mb-4 font-serif">
                {(post as EditorialData).excerpt}
                {isMain && (
                  <>
                    <br/><br/>
                    The evolution of digital layouts has been a fascinating journey. From the rigid table-based designs of the early web to the fluid, responsive grids we use today.
                  </>
                )}
              </p>
            </div>
          )}

          {!isParent && (
            <div className="mt-2">
              <PostActions 
                votes={post.votes} 
                replies={post.replies} 
                reposts={post.reposts} 
                shares={post.shares} 
                className="py-1"
              />
              {post.replies > 0 && !isMain && (
                <div className="flex items-center gap-1 mt-2 text-[11px] font-bold text-primary/80 hover:text-primary transition-colors">
                  <MessageCircle size={12} />
                  <span>{post.replies} {post.replies === 1 ? 'reply' : 'replies'}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </article>
  );
};

interface PostDetailPageProps {
  post: FeedItem;
  onBack: () => void;
}

export const PostDetailPage: React.FC<PostDetailPageProps> = ({ post, onBack }) => {
  const [replyText, setReplyText] = useState('');
  const [postStack, setPostStack] = useState<FeedItem[]>([post]);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  const currentPost = postStack[postStack.length - 1];
  const replies = useMemo(() => getReplies(currentPost), [currentPost.id]);

  React.useEffect(() => {
    setPostStack([post]);
  }, [post]);

  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [currentPost.id]);

  const handleBack = () => {
    if (postStack.length > 1) {
      setPostStack(prev => prev.slice(0, -1));
    } else {
      onBack();
    }
  };

  const navigateToStackIndex = (index: number) => {
    setPostStack(prev => prev.slice(0, index + 1));
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 100 }}
      transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
      className="fixed inset-0 z-[60] bg-background flex flex-col max-w-2xl mx-auto border-x border-white/5"
    >
      {/* Header */}
      <header className="sticky top-0 z-20 bg-background/80 backdrop-blur-xl border-b border-white/5 h-14 flex items-center px-4 gap-4">
        <button 
          onClick={handleBack}
          className="p-2 -ml-2 rounded-full hover:bg-white/10 transition-colors"
        >
          <ArrowLeft size={20} className="text-on-surface" />
        </button>
        <div className="flex flex-col">
          <h1 className="text-sm font-bold text-on-surface">Thread</h1>
          {postStack.length > 1 && (
            <span className="text-[10px] text-on-surface-variant font-medium">
              Replying to @{postStack[postStack.length - 2].author.handle}
            </span>
          )}
        </div>
      </header>

      {/* Scrollable Content */}
      <div ref={scrollRef} className="flex-grow overflow-y-auto hide-scrollbar pb-24">
        
        {/* Breadcrumb Path (Ancestors) */}
        <div className="pt-2">
          {postStack.slice(0, -1).map((parentPost, index) => (
            <ThreadPost 
              key={parentPost.id} 
              post={parentPost} 
              isParent={true}
              hasLineBelow={true} 
              onClick={() => navigateToStackIndex(index)} 
            />
          ))}
        </div>

        {/* Focused Post */}
        <ThreadPost 
          post={currentPost} 
          isMain={true} 
          hasLineBelow={replies.length > 0} 
        />

        {/* Replies Section */}
        <div className="flex flex-col border-t border-white/5 mt-2">
          {replies.length > 0 ? (
            replies.map((reply, index) => (
              <ThreadPost 
                key={reply.id} 
                post={reply} 
                hasLineBelow={index < replies.length - 1} 
                onClick={() => setPostStack(prev => [...prev, reply])} 
              />
            ))
          ) : (
            <div className="p-12 text-center">
              <p className="text-on-surface-variant text-sm opacity-50">No replies yet.</p>
            </div>
          )}
        </div>
      </div>

      {/* Reply Input */}
      <div className="fixed bottom-0 w-full max-w-2xl bg-surface-container/90 backdrop-blur-xl border-t border-white/5 p-3 flex items-end gap-3 z-20">
        <img 
          src="https://picsum.photos/seed/user/100/100" 
          alt="Your avatar" 
          className="w-9 h-9 rounded-full object-cover ring-1 ring-white/10 mb-1" 
          referrerPolicy="no-referrer" 
        />
        <div className="flex-grow relative">
          <textarea
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            placeholder={`Reply to ${currentPost.author.handle}...`}
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-2.5 px-4 text-[14px] text-on-surface placeholder:text-on-surface-variant/50 focus:outline-none focus:border-primary/50 focus:bg-white/10 transition-all resize-none min-h-[44px] max-h-[120px]"
            rows={1}
            style={{ height: replyText ? 'auto' : '44px' }}
          />
        </div>
        <button 
          disabled={!replyText.trim()}
          className="bg-primary text-primary-foreground font-bold text-[14px] px-4 py-2 rounded-full disabled:opacity-50 disabled:cursor-not-allowed hover:brightness-110 transition-all mb-1"
        >
          Reply
        </button>
      </div>
    </motion.div>
  );
};


